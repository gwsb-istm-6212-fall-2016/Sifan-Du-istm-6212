library(dplyr)

allzips <- read.csv("jobs.csv")
allzips <- allzips[!duplicated(allzips), ]
#allzips$latitude <- jitter(allzips$latitude)
#allzips$longitude <- jitter(allzips$longitude)
#allzips$college <- allzips$college * 100
#allzips$zipcode <- formatC(allzips$zipcode, width=5, format="d", flag="0")
#row.names(allzips) <- allzips$zipcode



city_jobs<-aggregate(formula=job_title ~ city+state,
                               data=allzips,FUN=length)

unique_cities <- read.csv("cod.csv")
unique_cities$latitude <- jitter(unique_cities$latitude)
unique_cities$longitude <- jitter(unique_cities$longitude)
#unique_cities <- allzips[!duplicated(allzips$city), ]
#unique_cities <- unique_cities[c('city','state','latitude','longitude')]

city_jobs <- merge(x = city_jobs, y = unique_cities, 
                   by.x = c("city","state") , 
                   by.y = c("city","state") , 
                   all = TRUE)
city_jobs<-na.omit(city_jobs)

cleantable <- allzips %>%
  select(
    Title = job_title,
    Company = company,
    City = city,
    State = state,
    Posted = day_posted
    #Zipcode = zipcode,
    #Rank = rank,
    #Score = centile,
    #Superzip = superzip,
    #Population = adultpop,
    #College = college,
    #Income = income,
    #Lat = latitude,
    #Long = longitude
  )
